# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from math import radians, cos, sin, atan2, degrees, sqrt
from rclpy.node import Node

from sensor_msgs.msg import NavSatFix
from interfaces.msg import Completed
#Type: sensor_msgs/msg/NavSatFix


def get_heading(longitude, latitude):
    lat1 = radians(latitude)
    lon1 = radians(longitude)
    lat2 = radians(51.42287924341543)
    lon2 = radians(-112.64106837507106)

    delta_lat = lat2 - lat1
    delta_lon = lon2 - lon1

    y = sin(delta_lon) * cos(lat2)
    x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(delta_lon)
    bearing = atan2(y, x)
    bearing = degrees(bearing)
    bearing = (bearing + 360) % 360
    heading = round(bearing, 1)
    return heading

def haversine(longitude, latitude):
    lat1 = radians(latitude)
    lon1 = radians(longitude)
    lat2 = radians(51.42287924341543)
    lon2 = radians(-112.64106837507106)

    delta_lat = lat2 - lat1
    delta_lon = lon2 - lon1

    a = sin(delta_lat / 2.0) ** 2 + cos(lat1) * cos(lat2) * sin(delta_lon / 2.0) ** 2
    c = 2 * atan2(sqrt(a),sqrt(1 - a))
    R = 6365.766   
    Dis = R * c * 1000
    Dis = round(Dis, 1)
    
    

    return Dis




class gps_dis(Node):

    def __init__(self):
        super().__init__("gps_dis")
        self.subscription = self.create_subscription(NavSatFix, 'GCS', self.listener_callback, 10)
        self.publisher = self.create_publisher(Completed, 'Dish', 10)
        #self.subscription  # prevent unused variable warning

    def listener_callback(self, msg: NavSatFix):
        cmp = Completed()
        self.get_logger().info('I heard: "%s"' % str(msg))
        
        cmp.latitude = msg.latitude
        cmp.longitude = msg.longitude
        cmp.heading = get_heading(msg.longitude, msg.latitude)
        cmp.distance = haversine(msg.longitude, msg.latitude)

        self.get_logger().info('I publish: "%s"' % str(haversine(msg.longitude, msg.latitude)))

        self.publisher.publish(cmp)

        


def main(args=None):
    rclpy.init(args=args)

    node = gps_dis()

    rclpy.spin(node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
