// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:msg/Example.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__EXAMPLE_H_
#define INTERFACES__MSG__EXAMPLE_H_

#include "interfaces/msg/detail/example__struct.h"
#include "interfaces/msg/detail/example__functions.h"
#include "interfaces/msg/detail/example__type_support.h"

#endif  // INTERFACES__MSG__EXAMPLE_H_
