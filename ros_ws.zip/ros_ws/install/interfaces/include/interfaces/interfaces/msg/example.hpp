// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__EXAMPLE_HPP_
#define INTERFACES__MSG__EXAMPLE_HPP_

#include "interfaces/msg/detail/example__struct.hpp"
#include "interfaces/msg/detail/example__builder.hpp"
#include "interfaces/msg/detail/example__traits.hpp"

#endif  // INTERFACES__MSG__EXAMPLE_HPP_
