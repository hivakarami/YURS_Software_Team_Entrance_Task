from interfaces.msg._completed import Completed  # noqa: F401
